var hour = new Date().getHours();

var msg;
if (hour < 12) {
  msg = "Good morning!";
} else if (hour < 18) {
  msg = "Good afternoon!";
} else {
  msg = "Good evening!";
}
alert(msg);

var num1 = 5;
var num2 = 5;

var sum = num1 + num2;

alert("The sum of " + num1 + " and " + num2 + " is: " + sum);

document.getElementById("colorButton").addEventListener("click", function () {
  var button = document.getElementById("colorButton");

  var randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);

  button.style.backgroundColor = randomColor;
});
