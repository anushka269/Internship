
const thumbnails = document.querySelectorAll ('.thumbnail');
const enlargedImage = document.querySelector('.enlarged-image img');
thumbnails.forEach(thumbnail => {
  thumbnail.addEventListener('click', () => {
    enlargedImage.src = thumbnail.src;
    enlargedImage.alt = thumbnail.alt;
    enlargedImage.parentElement.style.display = 'block';
  });
});
enlargedImage.parentElement.addEventListener('click', () => {
  enlargedImage.parentElement.style.display = 'none';
});


let slideIndex = 0;
showSlides();

function showSlides() {
  const slides = document.querySelectorAll('.mySlides');
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = 'none';
  }
  slideIndex++;
  if (slideIndex > slides.length) { slideIndex = 1 }
  slides[slideIndex - 1].style.display = 'block';
  setTimeout(showSlides, 2000); 
}